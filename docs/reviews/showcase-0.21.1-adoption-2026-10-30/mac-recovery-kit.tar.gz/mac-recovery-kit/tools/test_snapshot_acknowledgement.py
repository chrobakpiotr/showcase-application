"""Isolated real-Git trials; run with the reviewed, installed 0.20.0 wheel."""
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from agent_harness import state_snapshots as ss

TOOL = Path(__file__).with_name('snapshot_acknowledgement.py')
spec = importlib.util.spec_from_file_location('snapshot_acknowledgement', TOOL)
ack = importlib.util.module_from_spec(spec)
if TOOL.exists():
    spec.loader.exec_module(ack)


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name) / 'repo'
        self.repo.mkdir()
        self.git('init', '-q')
        self.git('config', 'user.name', 'fixture')
        self.git('config', 'user.email', 'fixture@invalid')
        self.git('commit', '--allow-empty', '-qm', 'fixture')
        self.root = self.repo / '.agent-state'
        self.root.mkdir()
        self.state = {'feature': 'API-ACCESS-001', 'feature_generation': 2,
                      'lifecycle_epoch_id': 'fixture-epoch', 'attempts': {'T-001': ['history']}}
        self.raw = ss.canonical_json(self.state)
        self.path = self.root / 'API-ACCESS-001.json'
        self.path.write_bytes(self.raw)
        self.path.chmod(0o600)
        self.seed = ss.commit_state_snapshot(self.repo, self.root, self.path, self.raw, self.state)
        self.old = self.seed['commit']
        # Preserve unrelated lifecycle history and an ordinary Git ref too.
        self.git('update-ref', 'refs/agent-state/OTHER-001', self.old)
        self.git('update-ref', 'refs/heads/unrelated', self.git('rev-parse', 'HEAD').strip())
        self.addition = self.root / 'wayfinder/EPIC-001/map.lock'
        self.addition.parent.mkdir(parents=True)
        self.addition.write_bytes(b'')
        self.addition.chmod(0o644)
        self.initial = self.inventory()
        self.before = self.refs()

    def git(self, *args, payload=None, check=True):
        result = subprocess.run(['git', '-C', str(self.repo), *args], input=payload,
                                capture_output=True, check=check)
        return result.stdout.decode()

    def refs(self):
        return dict(line.split(' ', 1) for line in self.git(
            'for-each-ref', '--format=%(refname) %(objectname)').splitlines())

    def inventory(self):
        return {str(p.relative_to(self.root)): (p.read_bytes(), p.stat().st_mode & 0o7777,
                                                p.stat().st_dev, p.stat().st_ino)
                for p in self.root.rglob('*') if p.is_file()}

    def run_ack(self, **kwargs):
        self.assertTrue(hasattr(ack, 'recover'), 'one-off recovery core is missing')
        return ack.recover(self.repo, operator='fixture operator', reason='isolated trial',
                           expected_commit=self.old,
                           expected_snapshot_id=self.seed['snapshot_id'], **kwargs)

    def audit(self):
        return next((self.repo / '.agent-runs/state-acknowledgements').iterdir())

    def assert_no_publication(self):
        self.assertEqual(self.refs(), self.before)
        self.assertFalse((self.repo / '.agent-runs').exists())

    def assert_success(self, result):
        after = self.refs()
        new = result['commit']
        archive = 'refs/agent-state-snapshots/API-ACCESS-001/' + result['snapshot_id'].split(':')[1]
        expected = {**self.before, archive: new,
                    'refs/agent-state/API-ACCESS-001': new, 'refs/agent-state/current': new}
        self.assertEqual(after, expected)
        self.assertEqual(self.inventory(), self.initial)
        old_manifest, old_files = ss._snapshot_tree_files(self.repo, self.old, ss._repo_identity(self.repo))
        manifest, files = ss._snapshot_tree_files(self.repo, new, ss._repo_identity(self.repo))
        self.assertEqual(files, {**old_files, 'wayfinder/EPIC-001/map.lock': (b'', 0o644)})
        for key in ['feature', 'repository_id', 'state_path', 'state_revision', 'epoch_id', 'feature_generation']:
            self.assertEqual(manifest[key], old_manifest[key])
        self.assertEqual(manifest['prior_files'], old_manifest['files'])
        self.assertEqual(ss.current_repository_state_status(self.repo, self.root), 'consistent')
        audit = self.audit()
        self.assertEqual(audit.stat().st_mode & 0o777, 0o700)
        intent = json.loads((audit / 'intent.json').read_bytes())
        result_audit = json.loads((audit / 'result.json').read_bytes())
        self.assertEqual(intent['before_refs'], self.before)
        self.assertEqual(result_audit['after_refs'], after)
        self.assertEqual(result_audit['postcheck'], 'consistent')
        self.assertNotIn('snapshot-acknowledgements', str(list(self.root.rglob('*'))))

    def test_success_and_repeat_preserve_state_history_and_full_ref_mapping(self):
        result = self.run_ack()
        self.assert_success(result)
        intent = (self.audit() / 'intent.json').read_bytes()
        repeated = self.run_ack()
        self.assertEqual(repeated['status'], 'already-applied')
        self.assertEqual(repeated['commit'], result['commit'])
        self.assertEqual((self.audit() / 'intent.json').read_bytes(), intent)
        self.assert_success(repeated)

    def test_refusals_do_not_publish(self):
        cases = ['extra', 'bytes', 'mode', 'special-mode', 'symlink-file', 'symlink-dir',
                 'claims', 'prepared', 'moved-feature', 'moved-current', 'canonical', 'missing',
                 'wrong-manifest', 'cap', 'state-root-symlink', 'audit-symlink']
        for case in cases:
            with self.subTest(case=case):
                self.tearDown()
                self.setUp()
                if case == 'extra':
                    (self.root / 'extra').write_bytes(b'')
                elif case == 'bytes':
                    self.addition.write_bytes(b'changed')
                elif case == 'mode':
                    self.addition.chmod(0o600)
                elif case == 'special-mode':
                    self.addition.chmod(0o4644)
                elif case.startswith('symlink'):
                    (self.root / 'link').symlink_to(self.path if case.endswith('file') else self.addition.parent)
                elif case == 'claims':
                    claim = self.root / 'wayfinder/OTHER/claims/claim.json'
                    claim.parent.mkdir(parents=True)
                    claim.write_bytes(b'{}')
                elif case == 'prepared':
                    self.git('update-ref', 'refs/agent-state-prepared/OTHER/' + 'a' * 64, self.old)
                elif case in ['moved-feature', 'moved-current']:
                    self.git('update-ref', 'refs/agent-state/' + ('API-ACCESS-001' if case == 'moved-feature' else 'current'),
                             self.git('rev-parse', 'HEAD').strip())
                elif case == 'canonical':
                    self.path.write_bytes(b'{}')
                elif case == 'missing':
                    self.addition.unlink()
                elif case == 'wrong-manifest':
                    self.seed['snapshot_id'] = 'sha256:' + '0' * 64
                elif case == 'cap':
                    for n in range(63):
                        self.git('update-ref', 'refs/agent-state-snapshots/API-ACCESS-001/' + format(n, '064x'), self.old)
                elif case == 'state-root-symlink':
                    self.root.rename(self.repo / 'moved-state')
                    self.root.symlink_to(self.repo / 'moved-state', target_is_directory=True)
                elif case == 'audit-symlink':
                    (self.repo / '.agent-runs').symlink_to(Path(self.temp.name), target_is_directory=True)
                self.before = self.refs()
                with self.assertRaises((ack.Refusal, ss.SnapshotError)):
                    self.run_ack()
                self.assertEqual(self.refs(), self.before)
                if case != 'audit-symlink':
                    self.assertFalse((self.repo / '.agent-runs').exists())

    def test_crash_before_cas_revalidates_and_reuses_identical_intent_commit(self):
        def stop(stage):
            if stage == 'before-cas':
                raise InterruptedError('simulated crash')
        with self.assertRaises(InterruptedError):
            self.run_ack(checkpoint=stop)
        self.assertEqual(self.refs(), self.before)
        intent = json.loads((self.audit() / 'intent.json').read_bytes())
        self.assertFalse((self.audit() / 'result.json').exists())
        result = self.run_ack()
        self.assertEqual(result['commit'], intent['new_commit'])
        self.assert_success(result)

    def test_crash_before_cas_does_not_accept_changed_tree(self):
        def stop(stage):
            if stage == 'before-cas':
                raise InterruptedError()
        with self.assertRaises(InterruptedError):
            self.run_ack(checkpoint=stop)
        self.addition.write_bytes(b'changed')
        with self.assertRaises(ack.Refusal):
            self.run_ack()
        self.assertEqual(self.refs(), self.before)

    def test_crash_after_cas_is_verified_before_finishing_audit(self):
        def stop(stage):
            if stage == 'after-cas':
                raise InterruptedError()
        with self.assertRaises(InterruptedError):
            self.run_ack(checkpoint=stop)
        self.assertFalse((self.audit() / 'result.json').exists())
        self.assert_success(self.run_ack())

    def test_success_then_refs_advance_never_republishes_stale_intent(self):
        self.run_ack()
        head = self.git('rev-parse', 'HEAD').strip()
        self.git('update-ref', 'refs/agent-state/current', head)
        after_advance = self.refs()
        with self.assertRaises(ack.Refusal):
            self.run_ack()
        self.assertEqual(self.refs(), after_advance)

    def test_forged_intent_commit_is_not_authority(self):
        result = self.run_ack()
        intent_path = self.audit() / 'intent.json'
        intent = json.loads(intent_path.read_bytes())
        intent['new_commit'] = self.old
        intent_path.write_bytes(ss.canonical_json(intent) + b'\n')
        after = self.refs()
        with self.assertRaises(ack.Refusal):
            self.run_ack()
        self.assertEqual(self.refs(), after)
        self.assertEqual(result['commit'], after['refs/agent-state/current'])

    def test_real_cas_race_changes_no_other_transaction_ref(self):
        head = self.git('rev-parse', 'HEAD').strip()
        def race(stage):
            if stage == 'before-cas':
                self.git('update-ref', 'refs/agent-state/current', head)
        with self.assertRaises((ack.Refusal, ss.SnapshotError)):
            self.run_ack(checkpoint=race)
        self.assertEqual(self.refs(), {**self.before, 'refs/agent-state/current': head})
        self.assertFalse((self.audit() / 'result.json').exists())

    def test_unrelated_ref_change_is_detected_in_postcheck(self):
        def race(stage):
            if stage == 'after-cas':
                self.git('update-ref', 'refs/heads/unrelated', self.old)
        with self.assertRaisesRegex(ack.Refusal, 'postcheck'):
            self.run_ack(checkpoint=race)
        self.assertEqual(json.loads((self.audit() / 'result.json').read_bytes())['postcheck'], 'ref-map-mismatch')

    def test_unlocked_state_change_is_reported_after_cas_without_rewriting_it(self):
        def race(stage):
            if stage == 'after-cas':
                self.addition.write_bytes(b'unlocked writer')
        with self.assertRaisesRegex(ack.Refusal, 'postcheck'):
            self.run_ack(checkpoint=race)
        self.assertEqual(self.addition.read_bytes(), b'unlocked writer')
        self.assertEqual(json.loads((self.audit() / 'result.json').read_bytes())['postcheck'], 'state-mismatch')

    def test_lifecycle_lock_blocks_separate_process_writer_through_postcheck(self):
        writer = None
        def check(stage):
            nonlocal writer
            if stage == 'before-cas':
                code = ('import fcntl,pathlib,sys; p=pathlib.Path(sys.argv[1]); '
                        'f=open(sys.argv[2],"a"); print("ready",flush=True); '
                        'fcntl.flock(f,fcntl.LOCK_EX); p.write_text("done")')
                writer = subprocess.Popen([sys.executable, '-c', code, str(self.repo / 'writer-done'),
                                           str(ss.lifecycle_lock_path(self.repo))], stdout=subprocess.PIPE, text=True)
                self.assertEqual(writer.stdout.readline().strip(), 'ready')
                time.sleep(0.15)
            self.assertFalse((self.repo / 'writer-done').exists())
        self.run_ack(checkpoint=check)
        writer.wait(timeout=5)
        writer.stdout.close()
        self.assertEqual(writer.returncode, 0)
        self.assertEqual((self.repo / 'writer-done').read_text(), 'done')

    def test_runtime_pin_and_cli_do_not_offer_override_flags(self):
        ack.require_runtime()
        with mock.patch.object(ack.agent_harness, '__version__', '0.21.0'), self.assertRaises(ack.Refusal):
            self.run_ack()
        with mock.patch.object(ack, 'REVIEWED_DIGEST', '0' * 64), self.assertRaises(ack.Refusal):
            self.run_ack()
        self.assert_no_publication()
        help_run = subprocess.run([sys.executable, str(TOOL), '--help'], capture_output=True, text=True, check=False)
        self.assertEqual(help_run.returncode, 0)
        for disallowed in ['--expected-commit', '--digest', '--skip', '--version-override', '--feature']:
            self.assertNotIn(disallowed, help_run.stdout)

    def subprocess_command(self, crash_stage=None):
        code = ('import importlib.util,json,os,pathlib,sys; '
                's=importlib.util.spec_from_file_location("ack",sys.argv[1]); '
                'm=importlib.util.module_from_spec(s);s.loader.exec_module(m); '
                'kw=json.loads(sys.argv[3]); '
                'kw["checkpoint"]=lambda stage: os._exit(88) if stage==sys.argv[4] else None; '
                'print(json.dumps(m.recover(pathlib.Path(sys.argv[2]),**kw)),flush=True)')
        kwargs = {'operator': 'fixture operator', 'reason': 'isolated trial',
                  'expected_commit': self.old, 'expected_snapshot_id': self.seed['snapshot_id']}
        return [sys.executable, '-c', code, str(TOOL), str(self.repo), json.dumps(kwargs), crash_stage or 'none']

    def test_real_process_crash_before_cas_recovers_same_commit(self):
        crashed = subprocess.run(self.subprocess_command('before-cas'), capture_output=True, check=False)
        self.assertEqual(crashed.returncode, 88, crashed.stderr)
        self.assertEqual(self.refs(), self.before)
        intent = json.loads((self.audit() / 'intent.json').read_bytes())
        result = self.run_ack()
        self.assertEqual(result['commit'], intent['new_commit'])
        self.assert_success(result)

    def test_real_process_crash_after_cas_completes_verified_audit(self):
        crashed = subprocess.run(self.subprocess_command('after-cas'), capture_output=True, check=False)
        self.assertEqual(crashed.returncode, 88, crashed.stderr)
        self.assertFalse((self.audit() / 'result.json').exists())
        result = self.run_ack()
        self.assertEqual(result['status'], 'already-applied')
        self.assert_success(result)

    def test_two_separate_recovery_processes_serialize_to_one_publication(self):
        first = subprocess.Popen(self.subprocess_command(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        second = subprocess.Popen(self.subprocess_command(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        first_out, first_err = first.communicate(timeout=10)
        second_out, second_err = second.communicate(timeout=10)
        self.assertEqual(first.returncode, 0, first_err)
        self.assertEqual(second.returncode, 0, second_err)
        results = [json.loads(first_out), json.loads(second_out)]
        self.assertEqual({r['status'] for r in results}, {'applied', 'already-applied'})
        self.assertEqual(results[0]['commit'], results[1]['commit'])
        self.assert_success(results[0])

    def test_retry_after_interrupted_ref_fsync_flushes_all_three_refs(self):
        with (mock.patch.object(ss, '_fsync_ref', side_effect=InterruptedError('ref fsync crash')),
              self.assertRaises(InterruptedError)):
            self.run_ack()
        self.assertFalse((self.audit() / 'result.json').exists())
        with mock.patch.object(ss, '_fsync_ref', wraps=ss._fsync_ref) as synced:
            result = self.run_ack()
        archive = 'refs/agent-state-snapshots/API-ACCESS-001/' + result['snapshot_id'].split(':')[1]
        self.assertEqual({call.args[1] for call in synced.call_args_list},
                         {archive, 'refs/agent-state/API-ACCESS-001', 'refs/agent-state/current'})
        self.assert_success(result)

    def test_existing_intent_result_and_directories_are_fsynced_on_retry(self):
        self.run_ack()
        synced = set()
        real_fsync = os.fsync
        def trace(fd):
            synced.add(os.readlink('/proc/self/fd/' + str(fd)))
            return real_fsync(fd)
        with mock.patch.object(os, 'fsync', side_effect=trace):
            self.run_ack()
        audit = self.audit()
        for path in [audit / 'intent.json', audit / 'result.json', audit, audit.parent, audit.parent.parent]:
            self.assertIn(str(path), synced)

    def test_interrupted_intent_fsync_is_completed_before_retry_publication(self):
        real_fsync = os.fsync
        def interrupt(fd):
            if os.readlink('/proc/self/fd/' + str(fd)).endswith('/intent.json'):
                raise InterruptedError('intent fsync crash')
            return real_fsync(fd)
        with mock.patch.object(os, 'fsync', side_effect=interrupt), self.assertRaises(InterruptedError):
            self.run_ack()
        self.assertEqual(self.refs(), self.before)
        synced_intent = False
        def trace(fd):
            nonlocal synced_intent
            if os.readlink('/proc/self/fd/' + str(fd)).endswith('/intent.json'):
                synced_intent = True
            return real_fsync(fd)
        def check(stage):
            if stage == 'before-cas':
                self.assertTrue(synced_intent, 'intent must be durable before publication')
        with mock.patch.object(os, 'fsync', side_effect=trace):
            self.assert_success(self.run_ack(checkpoint=check))

    def test_unreadable_subtree_refuses_instead_of_silently_omitting_extra_files(self):
        opaque = self.root / 'opaque'
        opaque.mkdir()
        (opaque / 'UNDECLARED').write_bytes(b'not in snapshot')
        real_scandir = os.scandir
        def unreadable(path):
            if not isinstance(path, int) and Path(path) == opaque:
                raise PermissionError('isolated unreadable directory trial')
            return real_scandir(path)
        with mock.patch.object(os, 'scandir', side_effect=unreadable), self.assertRaises((ack.Refusal, OSError)):
            self.run_ack()
        self.assert_no_publication()

    def test_forged_intent_cannot_waive_old_archive_preservation(self):
        def stop(stage):
            if stage == 'before-cas':
                raise InterruptedError()
        with self.assertRaises(InterruptedError):
            self.run_ack(checkpoint=stop)
        intent_path = self.audit() / 'intent.json'
        intent = json.loads(intent_path.read_bytes())
        old_archive = next(ref for ref in self.before if ref.startswith('refs/agent-state-snapshots/API-ACCESS-001/'))
        self.git('update-ref', '-d', old_archive)
        del intent['before_refs'][old_archive]
        intent_path.write_bytes(ss.canonical_json(intent) + b'\n')
        after_tamper = self.refs()
        with self.assertRaises(ack.Refusal):
            self.run_ack()
        self.assertEqual(self.refs(), after_tamper)


if __name__ == '__main__':
    unittest.main()
