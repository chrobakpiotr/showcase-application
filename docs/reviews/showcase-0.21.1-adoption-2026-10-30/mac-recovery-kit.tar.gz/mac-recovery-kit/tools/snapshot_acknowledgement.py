#!/usr/bin/env python3
"""ONE-OFF snapshot acknowledgement. No live use is authorized by this tool.

Internal, pinned to the installed 0.20.0 wheel. Read the adjacent procedure first.
Never writes the state root, runs recovery helpers, or applies retention.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.metadata
import json
import os
import re
import stat
from pathlib import Path

import agent_harness
from agent_harness import state_snapshots as ss

FEATURE = 'API-ACCESS-001'
OLD_COMMIT = 'd41f0aa9e6b8d6f5d011024bb5c29ac647f7c9cd'
REVIEWED_DIGEST = '793c8b9d95460af3eb46319e630352eda51d8a62011e580298db857389c0f12f'
ADDITION = {'path': 'wayfinder/EPIC-001/map.lock', 'type': 'regular', 'mode': 0o644,
            'bytes': 0, 'sha256': hashlib.sha256(b'').hexdigest()}
CURRENT = 'refs/agent-state/current'
FEATURE_REF = 'refs/agent-state/' + FEATURE
ARCHIVES = 'refs/agent-state-snapshots/' + FEATURE + '/'


class Refusal(RuntimeError):
    """Fail closed; a post-CAS refusal needs reconciliation, never rollback."""


def require_runtime():
    path = Path(ss.__file__)
    if (agent_harness.__version__ != '0.20.0' or
            importlib.metadata.version('agent-harness') != '0.20.0' or
            'site-packages' not in path.parts or
            hashlib.sha256(path.read_bytes()).hexdigest() != REVIEWED_DIGEST):
        raise Refusal('reviewed-installed-0.20.0-runtime-required')


def refs(repository):
    raw = ss._git(repository, 'for-each-ref', '--format=%(refname) %(objectname) %(symref)')
    result = {}
    for line in raw.decode('ascii').splitlines():
        ref, oid, symbolic = line.split(' ', 2)
        if symbolic:
            raise Refusal('symbolic-ref-unsupported')
        result[ref] = oid
    return result


def directory(path, *, create=False, private=False):
    """Reject symlinks at every component; fsync new directories and their parent."""
    if path == path.parent:
        return
    directory(path.parent)
    try:
        info = path.lstat()
    except FileNotFoundError:
        if not create:
            return
        path.mkdir(mode=0o700)
        ss._fsync_directory(path)
        ss._fsync_directory(path.parent)
        info = path.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise Refusal('audit-directory-unsafe')
    if private and (stat.S_IMODE(info.st_mode) != 0o700 or info.st_uid != os.getuid()):
        raise Refusal('audit-directory-not-private')
    if create:
        # Retry also completes durability after a crash between mkdir and its fsyncs.
        ss._fsync_directory(path)
        ss._fsync_directory(path.parent)


def read_record(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, 'rb') as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
            raise Refusal('audit-file-unsafe')
        try:
            raw = handle.read()
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            raise Refusal('audit-file-invalid') from None
        if raw != ss.canonical_json(value) + b'\n':
            raise Refusal('audit-file-noncanonical')
        return value


def immutable(path, value):
    payload = ss.canonical_json(value) + b'\n'
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        if read_record(path) != value:
            raise Refusal('immutable-audit-conflict') from None
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        ss._fsync_directory(path.parent)
        ss._fsync_directory(path.parent.parent)
        return
    with os.fdopen(fd, 'wb') as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    ss._fsync_directory(path.parent)
    ss._fsync_directory(path.parent.parent)


def inventory(root):
    """Read only regular files; unlike library mode masks, also reject special bits."""
    if not stat.S_ISDIR(root.lstat().st_mode):
        raise Refusal('state-root-unsafe')
    files = {}
    def walk_failed(error):
        raise Refusal('state-directory-unreadable') from error
    for base, dirs, names in os.walk(root, followlinks=False, onerror=walk_failed):
        base = Path(base)
        for name in dirs:
            if not stat.S_ISDIR((base / name).lstat().st_mode):
                raise Refusal('state-directory-unsafe')
        for name in names:
            path = base / name
            relative = path.relative_to(root).as_posix()
            if re.match(r'wayfinder/[^/]+/claims/', relative):
                raise Refusal('claims-file-present')
            if not stat.S_ISREG(path.lstat().st_mode):
                raise Refusal('state-file-unsafe')
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'rb') as handle:
                info = os.fstat(handle.fileno())
                mode = stat.S_IMODE(info.st_mode)
                if not stat.S_ISREG(info.st_mode) or mode not in ss._FILE_MODES:
                    raise Refusal('state-file-unsafe')
                files[relative] = (handle.read(), mode)
    return files


def identity(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise Refusal('addition-not-regular')
    return {'device': info.st_dev, 'inode': info.st_ino}


def snapshot(repository, commit):
    manifest, files = ss._snapshot_tree_files(repository, commit, ss._repo_identity(repository))
    # The pinned reader checks blobs and manifest modes but does not cross-check Git execute bits.
    expected = {'.agent-state/' + name: ('100755' if mode & 0o111 else '100644')
                for name, (_, mode) in files.items()}
    expected['manifest.json'] = '100644'
    actual = {}
    for row in ss._git(repository, 'ls-tree', '--full-tree', '-r', '-z', commit).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            actual[os.fsdecode(name)] = meta.decode('ascii').split(' ')[0]
    if actual != expected:
        raise Refusal('snapshot-git-mode-mismatch')
    return manifest, files


def recover(repository, *, operator, reason, expected_snapshot_id,
            expected_commit=OLD_COMMIT, checkpoint=None):
    """Private fixture seam: expected_commit is injected only by isolated tests.

    The CLI fixes both old refs to OLD_COMMIT, and exposes no runtime-pin override.
    checkpoint is solely an interruption/concurrency test seam, never a CLI flag.
    """
    require_runtime()
    if (not isinstance(operator, str) or not operator.strip() or
            not isinstance(reason, str) or not reason.strip() or
            not re.fullmatch(r'[0-9a-f]{40}', expected_commit) or
            not re.fullmatch(r'sha256:[0-9a-f]{64}', expected_snapshot_id)):
        raise Refusal('invalid-operation-inputs')
    repository = Path(repository).resolve(strict=True)
    if Path(os.fsdecode(ss._git(repository, 'rev-parse', '--show-toplevel')).strip()) != repository:
        raise Refusal('repository-root-required')
    lock_path = ss.lifecycle_lock_path(repository)
    lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(lock_fd).st_mode):
            raise Refusal('lifecycle-lock-unsafe')
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        opened = os.fstat(lock_fd)
        linked = lock_path.lstat()
        if (opened.st_dev, opened.st_ino) != (linked.st_dev, linked.st_ino):
            raise Refusal('lifecycle-lock-identity-changed')
        return _locked(repository, operator, reason, expected_commit, expected_snapshot_id, checkpoint)
    finally:
        os.close(lock_fd)


def _locked(repository, operator, reason, expected_commit, expected_snapshot_id, checkpoint):
    root = repository / '.agent-state'
    before = refs(repository)
    if any(ref.startswith('refs/replace/') for ref in before):
        raise Refusal('git-replacement-object-present')
    if any(ref.startswith('refs/agent-state-prepared/') for ref in before):
        raise Refusal('prepared-ref-present')
    inputs = {'repository_id': ss._repo_identity(repository),
              'expected_repository_commit': expected_commit, 'expected_feature_commit': expected_commit,
              'expected_snapshot_id': expected_snapshot_id, 'declared_addition': ADDITION,
              'operator': operator, 'reason': reason}
    op_id = hashlib.sha256(ss.canonical_json(inputs)).hexdigest()
    audit_root = repository / '.agent-runs/state-acknowledgements'
    audit = audit_root / op_id
    # Preflight the existing chain without creating audit entries on validation refusals.
    directory(audit_root)
    directory(audit, private=True)
    if audit_root.exists():
        directory(audit_root, private=True)
    intent_path = audit / 'intent.json'
    prior_intent = read_record(intent_path)
    old_manifest, old_files = snapshot(repository, expected_commit)
    if old_manifest['feature'] != FEATURE or old_manifest['snapshot_id'] != expected_snapshot_id:
        raise Refusal('expected-manifest-mismatch')
    if ADDITION['path'] in old_files:
        raise Refusal('declared-addition-already-in-old-tree')
    expected_files = {**old_files, ADDITION['path']: (b'', 0o644)}
    actual_files = inventory(root)
    if actual_files != expected_files:
        raise Refusal('state-inventory-mismatch')
    addition_identity = identity(root / ADDITION['path'])
    core = {key: value for key, value in old_manifest.items() if key != 'snapshot_id'}
    # A metadata-only acknowledgement preserves the old epoch/generation/revision/time.
    core.update(prior_files=ss._file_descriptor_rows(old_files),
                files=ss._file_descriptor_rows(expected_files))
    manifest = {**core, 'snapshot_id': 'sha256:' + ss.sha256_bytes(ss.canonical_json(core))}
    archive = ARCHIVES + manifest['snapshot_id'].split(':', 1)[1]
    already = False
    if prior_intent is not None:
        required = {'op_id', 'inputs', 'new_commit', 'snapshot_id', 'before_refs', 'addition_identity',
                    'operation_created_at'}
        if (not isinstance(prior_intent, dict) or set(prior_intent) != required or
                prior_intent['inputs'] != inputs or prior_intent['op_id'] != op_id or
                prior_intent['snapshot_id'] != manifest['snapshot_id'] or
                prior_intent['addition_identity'] != addition_identity):
            raise Refusal('intent-input-conflict')
        try:
            timestamp = dt.datetime.fromisoformat(prior_intent['operation_created_at'])
            if timestamp.tzinfo != dt.UTC:
                raise ValueError()
        except (ValueError, TypeError):
            raise Refusal('intent-time-invalid') from None
        new_commit = prior_intent['new_commit']
        if not isinstance(new_commit, str) or not re.fullmatch(r'[0-9a-f]{40}', new_commit):
            raise Refusal('intent-commit-invalid')
        new_manifest, new_files = snapshot(repository, new_commit)
        if new_manifest != manifest or new_files != expected_files:
            raise Refusal('intent-snapshot-mismatch')
        original = prior_intent['before_refs']
        if (not isinstance(original, dict) or original.get(CURRENT) != expected_commit or
                original.get(FEATURE_REF) != expected_commit or archive in original or
                any(ref.startswith('refs/agent-state-prepared/') for ref in original)):
            raise Refusal('intent-before-refs-invalid')
        after_expected = {**original, CURRENT: new_commit, FEATURE_REF: new_commit, archive: new_commit}
        if before == after_expected:
            already = True
        elif before != original or read_record(audit / 'result.json') is not None:
            raise Refusal('refs-advanced-reconcile-required')
        before = original
    else:
        if before.get(CURRENT) != expected_commit or before.get(FEATURE_REF) != expected_commit:
            raise Refusal('expected-ref-mismatch')
        if archive in before:
            raise Refusal('archive-already-present')
        if not any(ref.startswith(ARCHIVES) and oid == expected_commit for ref, oid in before.items()):
            raise Refusal('old-archive-missing')
        if sum(ref.startswith(ARCHIVES) for ref in before) >= ss.SNAPSHOT_LIMIT:
            raise Refusal('retention-cap-would-be-exceeded')
        # Refusals above have made no audit or state writes. Objects may now be created.
        new_commit = ss._commit_snapshot(repository, expected_files, manifest)
        prior_intent = {'op_id': op_id, 'inputs': inputs, 'new_commit': new_commit,
                        'snapshot_id': manifest['snapshot_id'], 'before_refs': before,
                        'addition_identity': addition_identity,
                        'operation_created_at': dt.datetime.now(dt.UTC).isoformat()}
        after_expected = {**before, CURRENT: new_commit, FEATURE_REF: new_commit, archive: new_commit}
    # An audit is output only: retries must independently preserve the old archive and cap too.
    if not any(ref.startswith(ARCHIVES) and oid == expected_commit for ref, oid in before.items()):
        raise Refusal('old-archive-missing')
    if sum(ref.startswith(ARCHIVES) for ref in before) >= ss.SNAPSHOT_LIMIT:
        raise Refusal('retention-cap-would-be-exceeded')
    for path in (repository / '.agent-runs', audit_root, audit):
        directory(path, create=True, private=path != repository / '.agent-runs')
    immutable(intent_path, prior_intent)
    if not already:
        if checkpoint:
            checkpoint('before-cas')
        transaction = ('start\n' + f'create {archive} {new_commit}\n' +
                       f'update {FEATURE_REF} {new_commit} {expected_commit}\n' +
                       f'update {CURRENT} {new_commit} {expected_commit}\n' + 'prepare\ncommit\n')
        ss._git(repository, 'update-ref', '--no-deref', '--stdin', input_bytes=transaction.encode('ascii'))
        if checkpoint:
            checkpoint('after-cas')
    # A post-CAS crash may have preceded any ref fsync. Verify and flush on every retry too.
    for ref in (archive, FEATURE_REF, CURRENT):
        ss._fsync_ref(repository, ref)
    after = refs(repository)
    status = ss.current_repository_state_status(repository, root)
    try:
        if inventory(root) != expected_files:
            status = 'state-mismatch'
    except (Refusal, OSError):
        status = 'state-unsafe'
    if after != after_expected:
        status = 'ref-map-mismatch'
    if identity(root / ADDITION['path']) != addition_identity:
        status = 'addition-identity-changed'
    result = {'op_id': op_id, 'after_refs': after, 'postcheck': status,
              'addition_identity': identity(root / ADDITION['path']),
              'operation_created_at': prior_intent['operation_created_at']}
    immutable(audit / 'result.json', result)
    if status != 'consistent':
        raise Refusal('postcheck-failed:' + status + '; reconcile without republishing')
    return {'status': 'already-applied' if already else 'applied',
            'commit': new_commit, 'snapshot_id': manifest['snapshot_id'], 'op_id': op_id}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--expected-snapshot-id', required=True)
    parser.add_argument('--operator', required=True)
    parser.add_argument('--reason', required=True)
    args = parser.parse_args()
    try:
        result = recover(args.repository, operator=args.operator, reason=args.reason,
                         expected_snapshot_id=args.expected_snapshot_id)
    except (Refusal, ss.SnapshotError, OSError, ValueError, TypeError) as error:
        parser.exit(2, f'REFUSED: {error}\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
