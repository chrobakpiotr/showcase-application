# One-off snapshot acknowledgement — isolated implementation only

This tool implements packet sections 8–13. Section 3 is historical and superseded where it specifies two locks or
an audit inside `.agent-state`. The tool takes **only the lifecycle lock** once, from dependent reads through the
three-ref CAS and final check. Its audit is outside the state root. It never changes canonical state or any state
file, creates prepared refs, prunes history, invokes lifecycle recovery helpers, or runs host qualification.
It is internal incident tooling, not an installed command or a supported API.

**No live recovery, cutover, deployment, release, or periodic execution is authorized.** An isolated fixture run
is not proof that the live host satisfies the entry conditions. Before a separately authorized live operation,
operators must verify the deployed writer protocol, deployed refusal markers for `SDD-001` and
`AH5-04B-QUAL-001`, and an audit directory protected from every agent sandbox under test. Mode 0700 is checked,
but is not a sandbox boundary for a process of the same user outside the sandbox. Historical Codex sandbox
proof in the packet does not qualify a new host; Claude's actual sandbox remains unverified. The tool does not
edit the registry, establish missing lifecycle history, qualify the host, or authorize its own execution.

On the reviewed 0.20.0 protections the packet records PASS with its stated limits. Main's marker port `cbd49fd`
is prepared, **not released or adopted**. The released 0.21.0 shim remains unsuitable for adoption until the marker
port is released. Nothing here closes AH5-14e-1 or authorizes a cutover.

The packet's legacy `exclusion_probe.py` is historical diagnostic tooling, not a readiness gate: it can exit 0
for a failed writer command and omits directory metadata. Verify writer exit outcomes and the inventory scope
independently; its earlier results do not establish live-host readiness.

## Frozen operation

The CLI fixes the feature to `API-ACCESS-001`, both expected old commits to
`d41f0aa9e6b8d6f5d011024bb5c29ac647f7c9cd`, and the addition to regular empty
`wayfinder/EPIC-001/map.lock`, mode 0644, SHA-256
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
The expected original manifest snapshot id, operator and reason are explicit inputs. Operator and reason are
audited statements, not authentication. The private `recover` function permits fixture old refs and checkpoints;
the CLI exposes neither, and offers no version, digest, feature or path override.

It refuses any prepared ref, changed old ref, unexpected file path/byte/mode/type, symlink, claims file, missing
old archive, different canonical bytes, retention-cap overflow, Git replacement object, symbolic ref, or unsafe
audit directory. The full before/after mapping covers **all Git refs**, preserving unrelated mappings too. Git's
`--no-deref` prevents an out-of-protocol symbolic-ref race from redirecting the mutation to another ref.

The new snapshot uses the reviewed library's `_commit_snapshot` and manifest encoding. Only `files`,
`prior_files` and `snapshot_id` change: revision, epoch, generation and `created_at` retain the original snapshot's
metadata. Here `created_at` means the original source snapshot time, **not the acknowledgement time**. The actual
acknowledgement operation time is recorded as `operation_created_at` in the external intent and result.
The new snapshot id is deterministic for the validated old snapshot and the declared addition. The commit is
built once and bound into the immutable intent before CAS; retries verify and reuse that exact commit.

The atomic transaction has exactly three writes: create one absent archive and update the two expected old refs
by CAS. Every old archive remains. Audit records are canonical JSON with mode 0600, created with `O_EXCL`; files,
directories and containing directory entries are fsynced. The operation id hashes the exact canonical inputs,
including repository id, both expected commits, expected snapshot id, addition descriptor, operator and reason.
Intent and result live in `.agent-runs/state-acknowledgements/<op-id>/`, outside `.agent-state`. The audit root
and operation directory must be owned by the operator and mode 0700. An interrupted partial audit is refused,
never overwritten or treated as authorization.

Before-CAS retry repeats inventory, manifest, ref and retention checks and verifies the intent's commit against
the expected tree and manifest. After-CAS retry additionally requires the complete expected ref mapping,
archive, unchanged lock identity and a consistent current state. A result file alone proves nothing.
If refs have advanced or the final check fails, **stop for reconciliation**. The tool does not roll back,
republish stale snapshots, remove audit records or retry in a loop. Failed final checks are audited when the
filesystem still permits writing the result. A crash can leave an intent without a result; that is not success.

After any separately authorized recovery, neither Wayfinder nor control-plane may run before cutover completes;
adoption must independently check the state again. Any new difference stops work. Moving operational state
outside `.agent-state` is a separate task required before normal Wayfinder/control-plane use resumes.

## Separate historical-runtime test gate

The normal `scripts/check-wheel.sh` tests the current package. It cannot silently substitute for this separate
0.20.0 gate, and these one-off tests are deliberately outside `tests/` so that installing the current package
does not weaken the pin. Build/install the actual 0.20.0 wheel in a fresh Python >=3.13 venv. The installed
`agent_harness.__version__` and distribution metadata must both say `0.20.0`; installed `state_snapshots.py` must
hash to `793c8b9d95460af3eb46319e630352eda51d8a62011e580298db857389c0f12f`.
The source digest comes from the read-only local `v0.20.0` Git object, and is fixed in the tool, not a CLI input.

Run from the repository root with the reviewed venv interpreter's absolute path:

```bash
bash docs/specs/showcase-state-recovery-2026-10-26/tools/test-snapshot-acknowledgement.sh /absolute/path/to/reviewed-0.20.0-venv/bin/python
/absolute/path/to/reviewed-0.20.0-venv/bin/python docs/specs/showcase-state-recovery-2026-10-26/tools/snapshot_acknowledgement.py --help
```

The test gate changes into a temporary directory and clears Python path overrides. It creates fresh temporary
Git repositories and genuine library snapshots. It covers publication and immutable state bytes/modes/inodes,
full ref preservation, all declared refusal classes, real Git CAS failure, before/after-CAS interruption and
hard process exits, audit verification, stale-ref refusal, an out-of-protocol writer detected by final check,
separate-process lifecycle-lock exclusion and two concurrent recovery processes. It performs no network or
live-repository operation. The `--help` smoke test is read-only; it is not an execution instruction for a host.
