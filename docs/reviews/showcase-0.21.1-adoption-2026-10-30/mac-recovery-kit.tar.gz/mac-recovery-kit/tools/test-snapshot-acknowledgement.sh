#!/usr/bin/env bash
# Separate from current-wheel tests: this historical one-off requires installed 0.20.0.
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo 'usage: test-snapshot-acknowledgement.sh /absolute/path/to/reviewed-0.20.0-venv/bin/python' >&2
  exit 2
fi
python=$1
case "$python" in
  /*) ;;
  *) echo 'an absolute interpreter path is required' >&2; exit 2 ;;
esac
tools=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cd "$work"
env -u PYTHONPATH -u PYTHONHOME "$python" -I -c '
import importlib.util, sys
assert sys.version_info >= (3, 13), "Python >=3.13 required"
spec = importlib.util.spec_from_file_location("ack", sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.require_runtime()
print("reviewed installed runtime:", module.agent_harness.__version__, module.ss.__file__)
' "$tools/snapshot_acknowledgement.py"
env -u PYTHONPATH -u PYTHONHOME "$python" -I -m unittest discover \
  -s "$tools" -p 'test_snapshot_acknowledgement.py' -v
