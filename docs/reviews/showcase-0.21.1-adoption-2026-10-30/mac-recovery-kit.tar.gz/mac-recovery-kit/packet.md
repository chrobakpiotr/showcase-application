# Showcase lifecycle state mismatch: Harness verification and recovery design (2026-10-26)

- **Status:** design for review. No live recovery and no cutover. Showcase stays on Harness 0.20.0 (`82d8b08`), and
  this package does not depend on AH5-14e-1 or the 0.21.0 adoption.
- **Basis:** Showcase's read-only diagnosis (`docs/reviews/lifecycle-state-mismatch-2026-10-26/DIAGNOSIS.md`, in its
  working tree), checked against the 0.20.0 code and against Showcase's repository, read only: refs, manifests and the
  file inventory; nothing was written.

## 1. Verified facts

- **The global snapshot belongs to `API-ACCESS-001`, not SDD-OBS-001.** `refs/agent-state/current` and
  `refs/agent-state/API-ACCESS-001` both point to `d41f0aa9e6b8d6f5d011024bb5c29ac647f7c9cd`. Its manifest: feature
  `API-ACCESS-001`, created 2026-10-18T20:13:12Z, epoch `legacy:2026-10-18T14:01:55.201935+00:00`, 61 files.
- **The state root's difference from it is exactly one file.** The extra file is
  `wayfinder/EPIC-001/map.lock`: a regular file, mode 0644, 0 bytes, SHA-256 `e3b0c442…b855`, mtime 2026-10-20
  12:44. Nothing is missing, and no other file differs in bytes or mode.
- **Why that blocks:** `current_repository_state_status` walks the whole state root, and a different path set returns
  `state-mismatch`, on which the lifecycle refuses.
- **The snapshot writer already covers the whole root.** `commit_state_snapshot` (via `_state_files`) snapshots every
  file under `.agent-state`, so any successful save would have absorbed the lock. Saves are refused first.
- **Retention:** `SNAPSHOT_LIMIT = 64`.
  - SDD-OBS-001 has **64** archive refs. A new SDD-OBS-001 snapshot would prune one, which is **not lossless**; it
    cannot be the vehicle.
  - `API-ACCESS-001` has 17, so a new snapshot of it prunes nothing.
- **No reflogs** exist for `refs/agent-state*`.

## 2. Wayfinder synchronization: no common exclusion exists

- **Map updates:** Wayfinder (`tooling/agent-harness/wayfinder.py` at Showcase HEAD) takes
  `flock(.agent-state/wayfinder/<epic>/map.lock, LOCK_EX)` only in `locked_map`. It never takes the lifecycle lock.
- **Claims, without either lock:**
  - `acquire_claim` creates `claims/<id>/` and `claim.json`;
  - `release_claim` removes it;
  - `active_claim` deletes expired or corrupt claims with `shutil.rmtree`, and is reached from the read-only
    `print_status` and `frontier`.

  None of these calls is inside `locked_map` (checked by AST).
- **Recent activity:** the empty `claims/` directory was modified on 2026-10-25 15:47, after the snapshot. Directories
  without files are not in the inventory.
- **Consequence:** no lock excludes all Wayfinder writers. Holding `map.lock` excludes only map updates, and a single
  scan finding no process proves nothing about the interval.

## 3. The limited operation ("acknowledge state file"), design

> Historical design: sections 8–13 supersede this section's two-lock protocol, audit-in-state tree,
> and retry details. The implemented operation takes only the lifecycle lock, keeps its audit outside
> `.agent-state`, and uses the stricter crash, CAS and precondition rules below.

A one-off, version-pinned tool. It refuses unless `agent_harness.__version__ == "0.20.0"` and the installed
`state_snapshots.py` has a reviewed digest. It publishes a new **repository** snapshot for **`API-ACCESS-001`** whose
tree equals the old snapshot plus the one declared file and one immutable audit record. It writes no state file.

1. **Inputs:**
   - the expected repository ref commit (`d41f0aa…`), the expected feature ref commit (the same), and the expected
     manifest snapshot id;
   - the declared addition: its exact path, `type=regular`, `mode=0644`, `bytes=0`, `sha256=e3b0…`;
   - the operator and a reason (audited, not authenticated).
2. **Under locks, in this order:** first `flock(map.lock, LOCK_EX)`, taken on the existing file opened read-only, so
   it is never created, replaced or renamed; then the lifecycle lock `lifecycle_lock_path(repo)`. Both are held
   through read, validation, the CAS publication and the post-check.
   - **Why the order is deadlock-free** (checked at Showcase `origin/main`): `map.lock` is used only by
     `wayfinder.py`'s `locked_map` (its four callers); Wayfinder never takes the lifecycle lock; and the Harness
     lifecycle code never takes `map.lock`. No caller holds both, so no reverse order exists.
   - **A missing `map.lock`:** the tool refuses; it does not create one.
3. **Refusals, any of which stops with nothing written:**
   - a prepared snapshot ref exists;
   - either ref differs from its expected commit;
   - the manifest is not the expected one;
   - the inventory differs from snapshot plus declared addition in any path, byte, mode or type;
   - a symlink anywhere;
   - any file under `wayfinder/*/claims/`;
   - the canonical state of `API-ACCESS-001` differs from the bytes in its snapshot;
   - `API-ACCESS-001` would exceed the retention cap.
4. **Publication:**
   - build the commit with the library's own manifest format (`_commit_snapshot`, the same core fields): state
     revision, epoch and generation unchanged; `prior_files` = the current tree; files = the tree plus the audit
     record `snapshot-acknowledgements/<id>.json` (operator, reason, old and new commits, declared addition and its
     digest; immutable, `_publish_immutable_file`);
   - then **one atomic `git update-ref --stdin` transaction with old values:** create the archive ref (old =
     absent), feature ref (old = `d41f0aa…`) and repository ref (old = `d41f0aa…`). A concurrent change makes the
     transaction fail, and nothing moves.
   - No state file is rewritten. Canonical state, attempts, leases, fingerprints and contracts are untouched.
5. **Interruption and retry:**
   - **before the transaction:** only unreferenced objects and possibly the audit file exist, and a retry repeats
     the checks (an audit file left behind is a declared, idempotent output with a deterministic id from the inputs);
   - **after the transaction:** a retry finds the refs at the new commit and reports "already applied" if that
     commit's audit record equals the inputs; otherwise it refuses;
   - no prepared ref is used, so `recover_prepared_snapshots` is never involved.
6. **Afterwards:** re-read under the same locks; `current_repository_state_status` must be `consistent`. Otherwise the
   tool reports and does not retry.
7. **Old snapshot:** `d41f0aa` keeps its archive ref; nothing is pruned (precondition).
8. **Concurrent Wayfinder writes** (§2: they cannot be excluded):
   - they cannot be lost, because the operation writes no state file;
   - they cannot be accepted unseen, because only the validated tree is published, and any later Wayfinder change
     makes the status `state-mismatch` again (fail-closed, detected by step 6 or the next lifecycle check).
   - **Decision for master:** whether this detection is acceptable for a one-off recovery, or whether Wayfinder's
     claims must first be brought under a common lock (a Showcase change).
9. **Verification plan:**
   - on an isolated copy (a mirror clone with its `refs/agent-state*`, plus a copy of `.agent-state`);
   - the success case;
   - each refusal (a second extra file, a changed byte, a wrong mode, a symlink, a claim file, a prepared ref, a
     moved ref, a cap overflow);
   - a concurrent ref change during the transaction;
   - interruption before and after the transaction, and the retry;
   - the post-check;
   - then an independent review.

**Not covered by this operation** (kept as separate problems):
- SDD-OBS-001's fingerprint difference, caused by the uncommitted spec/plan telemetry diff. It needs its own review
  and gate; no rebind and no fingerprint rewrite.
- The missing state of the two features (§5).

## 4. The cause: separating operational locks from snapshotted state (proposal, its own compatibility contract)

- **Move Wayfinder's operational files** (`map.lock`, `claims/`) out of the lifecycle-snapshotted `.agent-state/` into
  their own root (for example `<git-common-dir parent>/.agent-runs/wayfinder/<epic>/`, next to Showcase's existing
  `.agent-runs/control`), and take the claims operations under `map.lock`.
- **The compatibility contract must cover:** reading and migrating the old location once (under the lifecycle lock,
  through this same audited acknowledgement in reverse: an audited removal of the declared files from the snapshot);
  refusing if both locations hold claims; a fixed transition order.
- **No change to the snapshot rules:** no ignoring of `*.lock`, and no automatic acceptance of unknown files.

## 5. The two features without state

| Feature | Checked sources | Found | Classification |
|---|---|---|---|
| SDD-001 | canonical and legacy state paths (per the bindings), feature and archive refs, prepared refs, reflogs, task branches and worktrees, committed evidence | the spec directory only; no state, refs, branches, worktrees or evidence | **no state found in the checked sources**; this does not show that it never started |
| AH5-04B-QUAL-001 | the same | no state or refs, but **three task branches checked out in worktrees** (`T-002` `e37b09c`, `T-003` `7784562`, `T-004` `5025718`) and **245 committed evidence or result files** | **it ran; its lifecycle history (attempts, leases) was not found** |

- **History is not reconstructed** from specs, evidence or completion declarations.
- **Proposed behaviour:** keep both features refused for lifecycle mutations until history is established or an owner
  decision is taken. AH5-04B-QUAL-001's worktrees are left untouched, and its tasks' last states stay unknown.
- **To verify on an isolated copy before any decision:** what 0.20.0 does on the first lifecycle command for a feature
  without state while the repository snapshot exists. It must refuse, not initialise a fresh state.
- **The library migration itself, assessed separately:** these features hold no durable lease or attempt record that a
  code swap could orphan, since none was found. But AH5-04B-QUAL-001's worktrees mean an attempt could have been running
  when its state was lost. A swap does not change that risk; mutating those features does. A cutover with them kept
  refused is therefore not made less safe by them, but a decision is needed; no automatic consent is assumed.

## 6. Decisions for master

1. Whether the detection in §3.8 is acceptable, or whether Wayfinder's claims go under a common lock first.
2. Approval to implement the tool of §3 and test it on an isolated copy (then an independent review), before any live
   use.
3. Approval to verify §5's first-command behaviour on an isolated copy.
4. The compatibility contract of §4 as a separate Showcase change.

## 7. Blocker found on isolated fixtures: a feature without state is silently initialised

- **Fixture:** a `git archive` of Showcase `b4fd69d`'s documents (the real `SDD-001` and `AH5-04B-QUAL-001` specs),
  with the shim of each release.
  - Clean venvs from the tags. The `[grants]` extra was left out, because cryptography 49.0.0 has no Intel macOS
    wheel; `cryptography<49` was used instead.
  - A seed `claim` on `DEMO-002`, so that a consistent repository snapshot exists, as it would after the
    snapshot-only recovery.
  - A task branch and worktree for `AH5-04B-QUAL-001/T-002`, with a work file.
- **Script and logs:** `evidence-missing-state/` (`run.sh`; `run-0.20.0.log`, `run-0.21.0.log`;
  `refs-after-*.txt`). The script's "refs" fingerprint used a pattern that matched nothing and is not evidence; the
  ref lists are.
- **Result, the same on 0.20.0 and 0.21.0:**
  - `claim docs/specs/SDD-001 T-001` and `claim docs/specs/AH5-04B-QUAL-001 T-001` **succeed (`CLAIMED`)**. They
    create fresh state files (`SDD-001-….json`, `AH5-04B-QUAL-001-….json`) and new refs (`refs/agent-state/<feature>`,
    an archive ref each, and the advanced `refs/agent-state/current`).
  - `start` then refuses ("not ready"), `complete` refuses (no evidence), and `reconcile-feature` exits 2;
    `recover-stale` and `status` exit 0.
  - The existing worktree, its HEAD and its work file were **unchanged**.
- **Consequence:**
  - In the live repository the only protection today is the global `state-mismatch`, on which the lifecycle refuses
    every command.
  - A successful snapshot-only recovery would **remove that protection**: the next `claim` on either feature would
    start it from an empty state, which is exactly the forbidden initialisation.
  - 0.20.0 has no supported per-feature marker that forces a refusal: Showcase's incident authority is fixed to
    `SDD-OBS-001`.
- **Therefore:**
  - the snapshot-only recovery must **not** be executed until a refusal for these two features exists and is shown on
    fixtures;
  - the same holds for any cutover. A swap to 0.21.0 does not change this behaviour; both versions initialise.
- **Options, for decision:**
  1. A minimal, explicit fail-closed marker per feature, checked before any lifecycle mutation. For example, a
     Showcase-owned list of features whose state is "unestablished", read through the existing recovery binding
     (`state_recovery_required`), which already makes the lifecycle refuse. A Showcase change on 0.20.0, needing no
     library release.
  2. A library change ("refuse to initialise a feature when the repository has lifecycle history but the feature has
     none, unless explicitly authorised"). That is a behaviour change, a separate package and release.

  Option 1 is smaller and does not depend on a release; option 2 is the general fix.

## 8. The snapshot-only operation: answers to master's points (before implementation)

- **Refs in the one atomic transaction** (`git update-ref --stdin`: `start`, three commands, `prepare`, `commit`):
  - `create refs/agent-state-snapshots/API-ACCESS-001/<new snapshot id> <new>` (it must not exist);
  - `update refs/agent-state/API-ACCESS-001 <new> d41f0aa9e6b8d6f5d011024bb5c29ac647f7c9cd`;
  - `update refs/agent-state/current <new> d41f0aa9e6b8d6f5d011024bb5c29ac647f7c9cd`.

  No other ref is written or deleted, no prepared ref is used, and nothing is pruned.
- **History:** before and after, the tool records every ref under `refs/agent-state`, `refs/agent-state-snapshots` and
  `refs/agent-state-prepared`, with its value. The after set must equal the before set plus the one new archive ref,
  with the two updated refs as declared; otherwise the tool reports. `d41f0aa` stays reachable through its archive
  ref.
- **Audit, outside the snapshotted tree:**
  - location `<repository>/.agent-runs/state-acknowledgements/<op-id>/` (beside Showcase's `.agent-runs/control`),
    0700;
  - `op-id` = sha256 of the canonical inputs: the repository id, both old commits, the declared file (path, type,
    mode, bytes, sha256), the operator and the reason.
- **Binding the audit to the snapshot:**
  1. Build the commit with the library's `_commit_snapshot`. The tree is the old tree plus the declared file; the
     manifest is in the library's format, with state revision, epoch and generation unchanged.
  2. Write `intent.json` (the op-id, the inputs, the new commit and snapshot id, the before-refs), then fsync.
  3. Run the CAS transaction.
  4. Write `result.json` (the after-refs, the post-check status), then fsync.
- **A crash between `intent.json` and the CAS:** the refs are unchanged. A retry finds the intent with the same op-id,
  validates again from scratch, and publishes the same commit if its tree still equals the validated tree. Otherwise it
  refuses.
- **A crash after the CAS, before `result.json`:** "already applied" requires all of these:
  - the refs are exactly at the intent's commit;
  - that commit's tree equals the old tree plus the declared file, and its manifest is `API-ACCESS-001`'s, with the
    unchanged state revision;
  - the archive ref exists;
  - the post-check is `consistent`.

  Then `result.json` is written. The mere existence of an audit file is never enough.
- **Never written:** canonical state, other lifecycle files, `map.lock`. Its inode is recorded before and after and
  must be unchanged. Any unexpected difference refuses.
- **Synchronisation:** the operation runs only after Showcase's change has put every claims mutation under the common
  `map.lock` (master's point 1). Harness checks that change's lock order against the lifecycle.
- **Other writers of the snapshotted tree, found by the sweep:**
  - `control_plane.py` writes `.agent-state/control-plane/*.json` with no lock. It is absent now; it needs the same
    treatment, or a refusal of the operation if present.
  - The shim's lifecycle commands write under the lifecycle lock, except some bare `mkdir`s (directories are not in the
    inventory). Their callers' lock scope is to be confirmed in implementation.

## 9. One locking protocol for every writer of the snapshotted tree (Harness's proposal for the Showcase changes)

**The lock:** the repository's lifecycle lock, an exclusive `flock` on `<git common dir>/agent-state-lifecycle.lock`
(`state_snapshots.lifecycle_lock_path`, the same file `feature_state.lock_path` returns). It already serialises every
lifecycle mutation of every feature, and it lies **outside** `.agent-state`, so taking it changes no inventory.

**The rule:** every creation, change or removal of a file **or directory** under `.agent-state` happens while the
process holds that lock exclusively, from the first check on which the write depends until the write is durable. There
are no exceptions for read-only commands that clean up.

**Lock order, global:**
- any other lock a writer uses (Wayfinder's `map.lock`) is taken **before** the lifecycle lock and released after it;
- a holder of the lifecycle lock never waits for any other lock;
- lifecycle code takes only the lifecycle lock (as today);
- the recovery tool takes only the lifecycle lock. It needs no `map.lock`, because every writer then excludes it
  through the lifecycle lock, and it never opens, creates or replaces `map.lock`.

So no cycle is possible: the only two-lock holder is Wayfinder, always in the order `map.lock` → lifecycle lock.

**The minimal Showcase changes this implies** (Showcase implements; Harness verifies):
- **`wayfinder.py`:**
  - `acquire_claim`, `release_claim` and `active_claim`'s cleanup (including the calls from `print_status` and
    `frontier`) take the lifecycle lock around their `.agent-state` writes;
  - `locked_map` keeps `map.lock` for map serialisation, but creates `map.lock` (and its directory) only under the
    lifecycle lock, after which it takes `flock(map.lock)` and then, for any `.agent-state` write inside, the lifecycle
    lock;
  - a Wayfinder process holding the lifecycle lock never takes `map.lock`.
- **`control_plane.py`:** `STATE.mkdir` and each `write_text` run under the lifecycle lock (no other lock).
- **No moving of files** in this change (the separate package of §4).

**Verification Harness will run on the Showcase change** (isolated copies, on 0.20.0, and the integration on 0.21.0):
1. **Static:** an AST inventory of every write under `.agent-state` in `wayfinder.py`, `control_plane.py` and the shim,
   each inside a lifecycle-lock scope; no acquisition of `map.lock` inside a lifecycle-lock scope.
2. **Exclusion:** a process holding the lifecycle lock (as the recovery tool will) blocks a concurrent Wayfinder claim,
   release and status cleanup, and a control-plane write. Each completes only after release, and none writes during
   the hold (the inventory is taken before and after the hold).
3. **Deadlock freedom:** concurrent Wayfinder mutations, lifecycle commands and the tool's lock pattern under load all
   finish (with a timeout as failure).
4. **Behaviour unchanged:** Wayfinder's and control-plane's own tests pass.

**What this does not fix:** a Wayfinder or control-plane write still changes the inventory without a lifecycle
snapshot, so `state-mismatch` would recur after any such write. The protocol only gives the recovery tool exclusion.
Ending the recurrence is §4's package (moving operational files out of `.agent-state`).

## 10. The snapshot-only operation: master's refinements (2026-10-26), as the implementation contract

- **The ref set grows by exactly one name:** `refs/agent-state-snapshots/API-ACCESS-001/<new id>`.
- **Exactly two existing refs change value, each by CAS:** `refs/agent-state/API-ACCESS-001` and
  `refs/agent-state/current`, both from `d41f0aa…` to the new commit.
- **Every other ref → commit mapping is identical** before and after. The check compares the full mappings, not
  counts.
- **`intent.json` is immutable**, created with `O_EXCL`. A retry compares its inputs field by field and refuses on any
  difference.
- **Durability covers the audit directory and its entries:** fsync of each file, and of the directory and its parent
  after each creation.
- **The audit grants nothing:** it is an output only. Its directory (`.agent-runs/state-acknowledgements/`, 0700)
  and its protection are to be checked against the agent sandboxes (it must not be writable by an agent under test).
- **A later, legitimate change of the refs after a successful CAS:** the tool reports a state to be reconciled. It
  never republishes the old snapshot.
- **Preconditions before implementation:** §9 in place and verified, and the option-1 marker (master's decision)
  in place and verified for SDD-001 and AH5-04B-QUAL-001.

## 11. Master's refinements to §9 and §10 (2026-10-26), as the contract to verify

**`map.lock` bootstrap, separated from taking its `flock`:**
1. Under the lifecycle lock, without waiting for `map.lock`: create the epic directory and `map.lock` if missing (an
   existing one is never replaced or removed).
2. Release the lifecycle lock.
3. Take `flock(map.lock)`, then the lifecycle lock, before the dependent read and the mutation.

At each use, check the file's identity: the `(st_dev, st_ino)` of the open descriptor equals the path's, otherwise
refuse. Never wait for `map.lock` while holding the lifecycle lock.

**Scope:**
- **Covered explicitly**, besides claims and the lock's creation: the map's own write through `atomic_json()`, with its
  temporary files and the rename.
- **The AST inventory is an aid only.** I/O helpers, subprocesses and nested calls are checked as well.
- **No second `flock`** on a separately opened descriptor when the caller already holds the lifecycle lock (re-taking
  an `flock` on a new open file description in the same process would deadlock). The shared transaction keeps its
  present behaviour.
- **The absence of a cycle** is to be confirmed on the real callers, not assumed.

**The snapshot-only tool** takes only the lifecycle lock, and only once every writer in scope demonstrably respects it.
§10 is accepted. **Entry conditions:**
- the writers' protocol deployed and verified;
- the refusal marker deployed for both features;
- exactly the allowed inventory difference;
- the audit's protection checked.

**The limit of the repair** (recorded in the procedure):
- from the recovery's final check until the cutover is complete, **neither Wayfinder nor control-plane is run**;
- the tool and the adoption each check the state again, and any new difference stops the work;
- moving the operational data out of the snapshot is a separate task, required before those tools return to normal
  use;
- snapshot-only is **never** run periodically as a workaround.

**Order:** Showcase's writer changes and marker (separate commits) → Harness verifies both on 0.20.0 and 0.21.0 → the
tool in isolation, with crash and concurrency trials → independent review → a separate decision on live recovery.

## 12. Verification tooling, prepared before Showcase's changes

**Historical diagnostic only:** `exclusion_probe.py` can return exit 0 even when a writer command exits nonzero,
and does not inventory directory metadata. Its earlier trials are not a host-readiness or writer-success gate.
Any later probe must check command outcomes and its exact inventory scope independently; no live readiness is
inferred from these historical results.

- **`tools/exclusion_probe.py`:** it holds the repository lifecycle lock (`<git common dir>/agent-state-lifecycle.lock`,
  exclusively), exactly as the recovery tool will. It starts the given writer commands concurrently, and takes the
  `.agent-state` inventory (paths, directories, mode, size, inode, sha256) before, at the end of and after the hold.
  It exits 1 on any change during the hold, and records, per command, whether it finished before the release.
- **Self-test:** a writer taking the lock waited (its file appeared only after the release); an unlocked `touch` was
  detected during the hold (exit 1).
- **Planned use on Showcase's writer change:** Wayfinder claim, release, status cleanup and map write, the creation of
  a new epic's `map.lock`, and control-plane writes. Each on 0.20.0 and 0.21.0 isolated copies, with a timeout as the
  deadlock check.
- **For the marker:** `evidence-missing-state/run.sh` again, expecting `claim` (and every path that could create state)
  to be refused, no new state files and no new refs, while the snapshot is consistent. Plus a garbled and an unreadable
  registry, each refused rather than read as empty.

## 13. Harness review of the recovery protections (Showcase `ff15af79c63ff174ea79bffaa2f36e802fb02e6c`, 2026-10-26)

**Reviewed:**
- `e8b86363` (Wayfinder and control-plane writers);
- `fa30c7f7` (the refusal marker);
- `280dcc0c` (marker path resolution);
- `ff15af79` (read-only `--plan`).

Code base `ff15af7`. `a391f24f3f02c640dea9a8555b73fd303cb53319` (the DRA evidence) is the direct **parent** of
`ff15af7`, not a later commit, and is in `origin/main` (= `ff15af7`).

**Verdict:**
- **0.20.0:** PASS for the protections, with the limits below.
- **0.21.0:** **FAIL as released (a blocker for any 0.21.0 adoption).** With the shim exactly as it is in the 0.21.0
  release, `claim` succeeds for both features and creates fresh state files and refs
  (`marker-0.21.0-release-shim-absent.log`).

  **Why:** the marker lives only in Showcase's locally patched shim (`fa30c7f7` modifies
  `tooling/agent-harness/harness.py`). The agreed adoption copies Harness's shim, which would drop the marker. With the
  marker ported into the 0.21.0 shim (16 hunks apply as they are; the two refusals of `cmd_restore_state` and
  `cmd_discard_prepared_snapshot` go into their 14d delegates, before the library call), 0.21.0 refuses exactly like
  0.20.0.

  **Required:** Harness carries the marker in `migration/showcase-wrapper/harness.py` (on `main` and in AH5-14e-1)
  and releases it before any cutover.

**Evidence** (`evidence-protections/`, with SHA256SUMS; isolated `git archive` copies of `ff15af7`, clean venvs from the
tags; the logs are raw, exempt from the whitespace check by `.gitattributes`):

1. **The marker, on a consistent repository snapshot** (a seed `claim` on `DEMO-002`):
   - every state-creating command on both features is refused: `claim`, `start`, `recover-stale`, `reopen`,
     `authorize-retry` (`STATE_RECOVERY_REQUIRED` or `STATE_RECOVERY_REGISTRY_INVALID`); `reconcile-feature` exits 2;
   - **the state files and all refs are unchanged** in each case;
   - registry cases on 0.20.0: absent, garbled, unreadable (mode 000), valid but missing a required feature. On 0.21.0
     with the ported shim: absent and garbled.
2. **Registry binding:**
   - the same registry file from the main checkout and from a linked worktree (same git common dir);
   - refusals hold from an unrelated cwd, through either checkout's harness;
   - "the repository" is the consumer checkout (`REPO = HERE.parents[1]` of the shim), not the library or its install
     directory.
3. **The real sandbox boundary, without a model:** `codex sandbox` in `workspace-write`, run from an agent worktree,
   denied every attempt (exit 1):
   - appending to, deleting or renaming the registry;
   - creating a file or directory in its parent;
   - editing the main checkout's `unknown_state_registry.py`.

   The positive control (a write in the workspace) succeeded. Registry and code are byte-identical afterwards.
   - **Not verified:** Claude's real sandbox (it needs a model turn; the runner does add the registry directory to
     `denyRead`/`denyWrite`); a process of the same user outside any sandbox (the orchestrator itself), against which a
     file permission is no boundary.
4. **Writers' protocol:**
   - **Wayfinder** (`locked_claim_state`): it refuses if the lifecycle lock is already held; bootstraps `map.lock` under
     the lifecycle lock (`_ensure_map_lock`) and releases it; opens the existing lock with `O_NOFOLLOW` and checks its
     `(st_dev, st_ino)` before and after taking `flock`; then takes the lifecycle lock. The map's `atomic_json` write
     runs inside both locks.
   - **Control-plane:** `mkdir`, temporary file, fsync, `os.replace` and the directory fsync, all under the lifecycle
     lock.
   - **Re-entry:** Showcase's helper reuses a thread's held lifecycle lock instead of a second `flock`.
   - **No hidden library lock:** no `h.` (shim) call appears inside any locked Wayfinder block. The shim names
     Wayfinder uses (`FEATURE_ID_RE`, `design_gate_errors`, `execution_base`, `repo_root`, `validate`) take no lock,
     so no path takes the library's `flock` on a second descriptor.
   - **No cycle:** the only two-lock holder is Wayfinder, always `map.lock` → lifecycle.
   - **Measured** with `tools/exclusion_probe.py`, holding the lifecycle lock for 3 s: Wayfinder `status` and `frontier`
     with an expired claim planted made **no change during the hold**, finished after the release, and removed the
     claim then. `status` bootstrapped the missing `map.lock` only after the release.
   - **Not exercised dynamically:** control-plane (its commands need a tracker) and the map writers. Both are checked
     statically here and by Showcase's tests.
5. **Diagnostics:** `orchestrate --plan` on both features exits 0, reports `recovery-required` and `unknown` for every
   task, and leaves state and refs unchanged. The same command without `--plan` is refused with
   `STATE_RECOVERY_REQUIRED`, also unchanged. The runner's preview was not exercised separately.

**Open before the snapshot-only tool:**
- the 0.21.0 blocker above (Harness: the marker in its shim, then a release);
- Claude's sandbox boundary stays unverified without a model run;
- the tool can now take only the lifecycle lock, because every writer in scope demonstrably respects it.

### Marker port prepared for main (2026-10-29)

The candidate `migration/showcase-wrapper/harness.py` now carries the reviewed marker policy, including refusals
before the library's restore/discard delegates. The generic library's behaviour is unchanged;
`unknown_state_registry.py` remains Showcase-owned and must remain present when the candidate shim is copied.
The adoption regression copies the candidate shim over Showcase tooling and checks both unresolved features against
a consistent repository snapshot, including unchanged state bytes and lifecycle refs. This is not a release,
adoption, live recovery, or acceptance of AH5-14e-1; that branch's port and the release remain outstanding.

## 14. One-off isolated implementation (2026-10-29)

**Scope:** `tools/snapshot_acknowledgement.py`, its separate pinned-runtime fixture tests and procedure in `tools/`.
The operation implements sections 8–13; the conflicting parts of section 3 are historical. No installable package
API or runtime source changes. No live operation, cutover, release, marker deployment or host qualification.

The CLI fixes the incident's old commits, feature and declared file; both installed version 0.20.0 and the
reviewed `state_snapshots.py` SHA-256 are mandatory, with no override flags. The fixture core alone permits
injected expected old commits. One lifecycle lock covers dependent reads, validation, immutable external audit,
three-ref atomic CAS, durability and post-check. The complete Git ref mappings and state file identity are checked;
no state file is written and no archive is pruned. Unscannable directories fail closed.

A retry verifies the intent's exact inputs, snapshot tree/manifest and complete expected ref mapping. It also
finishes all audit-directory/file and three-ref fsyncs, including a crash after CAS but before the first fsync.
An advanced ref or failed final check requires reconciliation, never stale republication. A snapshot's original
`created_at` remains the source snapshot time; external intent/result record the acknowledgement operation time.

See [the isolated procedure](tools/README.md) for entry conditions, frozen inputs, refusal/crash behavior and
[the separate 0.20.0 test gate](tools/test-snapshot-acknowledgement.sh). The current-package wheel gate is separate;
it does not exercise this historical-runtime tool. All fixture operations use temporary Git repositories.

Independent review of the isolated implementation: **PASS WITH FINDINGS**, with four initial blockers fixed and regression-tested; no unresolved blocker in this tool. See [the exact hashes, findings and independent 20-test run](evidence-snapshot-only/independent-review.md). The 0.20.0 safeguards PASS in section 13
retains its original scope and limits. Main's `cbd49fd` marker port is not a release or adoption. No result here
qualifies the live host or replaces the separate authorization and protected-audit/deployed-writer/marker checks.


### 2026-10-29 cross-process evidence and remaining boundaries

[Writer probes](evidence-writer-processes/README.md) exercise exact Showcase
`e5b54adaf7ea4a38e4626f5750da6561db41d688` sources on temporary repositories with installed Harness 0.20.0.
Map and control-plane writers reach real lifecycle flock calls in separate processes, leave complete inventories
unchanged during the hold, and finish with the expected writes after release. The bounded load produces map
counter 80 and 40 control-plane files. Source identities, raw inventories and checksums are preserved.

The load's lifecycle participant takes the lock and inventories; it does **not** execute a full lifecycle
command/state mutation. This closes the narrow map/control-plane process-exclusion evidence gap, not every
section-9 integration/load criterion. The [preconditions review](evidence-snapshot-only/preconditions-review.md)
records earlier coverage and scope. Legacy `exclusion_probe.py` is only a historical diagnostic, not a readiness
gate: its success can omit failed writers and directory metadata changes.

Current-package local full-gate failures and targeted reruns remain separately recorded in
[the implementation report](evidence-snapshot-only/REPORT.md). No local full-gate PASS is claimed.
The isolated tool, audit permission checks and this evidence do not authorize live recovery, establish live
state, qualify a sandbox, or release/adopt the marker-carrying shim. Those decisions and checks remain open.
