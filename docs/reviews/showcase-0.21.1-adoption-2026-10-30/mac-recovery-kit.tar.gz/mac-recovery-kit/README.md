# Mac recovery kit

Frozen reviewed inputs only; no live state or secrets. Remote code adoption does not mean Mac adoption. The owner has authorized adoption/recovery; technical prerequisites still apply.

1. Check the archive SHA-256 against the delivery record, then extract into a private operator-controlled directory outside agent writable roots.
2. From extracted `mac-recovery-kit` run `shasum -a 256 -c SHA256SUMS`. Stop on any failure.
3. Set `KIT_DIR` to that directory's actual absolute path and follow `mac-recovery-runbook.md` in order. Preserve protected old consumer code and the separate 0.20.0 environment before updating the live checkout.
4. Inputs: `tools/snapshot_acknowledgement.py`, its tests/README, `packet.md`, and `wheels/agent_harness-0.20.0-py3-none-any.whl`. The runbook derives `TOOL` and `WHEEL020` from `KIT_DIR`. Do not alter tool constants or use its private fixture seam for live recovery.

The frozen README/packet describe publication-time lack of live authorization. The later owner order supplies authorization while every technical prerequisite remains. No paid/model/sandbox canary is included. Never invent a manifest ID or Mac path. Missing writer/drain/denial-boundary evidence is a hard stop.
